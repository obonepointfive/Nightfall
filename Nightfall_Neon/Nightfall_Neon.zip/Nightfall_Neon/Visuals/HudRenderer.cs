﻿using HelixToolkit.Geometry;
using HelixToolkit.Maths;
using HelixToolkit.Wpf.SharpDX;
using SharpDX;
using System.IO;
using System.Numerics;
using System.Windows.Media.Imaging;

namespace Nightfall.Visuals
{
    public static class HudRenderer
    {
        public static MeshGeometry3D CreateFullscreenQuad()
        {
            // Simple -1..1 quad in XY, Z=0
            var builder = new MeshBuilder();
            builder.AddQuad(
                new Vector3(-1, -1, 0),
                new Vector3(1, -1, 0),
                new Vector3(1, 1, 0),
                new Vector3(-1, 1, 0));
            return builder.ToMeshGeometry3D();
        }

        public static PhongMaterial CreateHudMaterial(string relativePath)
        {
            var fullPath = Path.Combine(AppDomain.CurrentDomain.BaseDirectory, relativePath);

            var image = new BitmapImage(new Uri(fullPath, UriKind.Absolute))
            {
                CacheOption = BitmapCacheOption.OnLoad
            };

            return new PhongMaterial
            {
                DiffuseMap = image,
                DiffuseColor = Color.White,
                EmissiveColor = new Color4(0.0f, 0.8f, 1.0f, 1.0f), // cyan glow
                ReflectiveColor = new Color4(0, 0, 0, 1),
                SpecularColor = new Color4(0, 0, 0, 1),
                RenderDiffuseMap = true
            };
        }
    }
}
